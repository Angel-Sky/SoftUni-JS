Hi! :)
The server is listening on port 3000, so the adress is: http://localhost:3000/
Start it with:
npm start 

Have a nice day!